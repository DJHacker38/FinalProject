






/*
<div class="ui-block-b" style="text-align: center;">
    <a href="#" data-role="button"><img src="picture/clothes/4.jpg" width=50% height=50%></a>
    <h3>good looking clothes4</h3>
</div>
*/