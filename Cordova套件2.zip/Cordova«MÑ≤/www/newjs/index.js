window.onload = function(){
    window.location = "index2.html";
}